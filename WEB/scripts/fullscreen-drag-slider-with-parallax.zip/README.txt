A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/MyedLG.

 Sort of responsive. Tested in Chrome/FF/last IE, everywhere looks fine.

Source of inspiration - https://stupid-studio.com/ (their js is minified, so all code is mine, except some parts of svg, like viewBox/minHeight).

Forked from [Nikolay Talanov](http://codepen.io/suez/)'s Pen [Fullscreen drag-slider with parallax](http://codepen.io/suez/pen/ByvKXE/).